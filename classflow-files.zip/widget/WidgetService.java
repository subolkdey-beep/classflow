package com.subol.classflow;

import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;
import java.util.ArrayList;

public class WidgetService extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new Factory(getApplicationContext());
    }

    static class Factory implements RemoteViewsService.RemoteViewsFactory {
        final Context ctx;
        ArrayList<ClassWidget.Row> rows = new ArrayList<ClassWidget.Row>();

        Factory(Context c) {
            ctx = c;
        }

        void load() {
            try {
                rows = ClassWidget.compute(ctx).rows;
            } catch (Exception e) {
                rows = new ArrayList<ClassWidget.Row>();
            }
        }

        @Override
        public void onCreate() {
            load();
        }

        @Override
        public void onDataSetChanged() {
            load();
        }

        @Override
        public void onDestroy() {
        }

        @Override
        public int getCount() {
            return rows.size();
        }

        @Override
        public RemoteViews getViewAt(int i) {
            if (i < 0 || i >= rows.size()) {
                return null;
            }
            ClassWidget.Row r = rows.get(i);
            if (r.type == 1) {
                RemoteViews b = new RemoteViews(ctx.getPackageName(), R.layout.widget_break);
                b.setTextViewText(R.id.w_b_text, r.title);
                if (r.state == 3) {
                    b.setInt(R.id.w_b_text, "setBackgroundResource", R.drawable.widget_break_bg);
                    b.setTextColor(R.id.w_b_text, 0xFFFFE08A);
                } else if (r.state == 4) {
                    b.setInt(R.id.w_b_text, "setBackgroundResource", R.drawable.widget_free_bg);
                    b.setTextColor(R.id.w_b_text, 0xFFA7F3D0);
                } else {
                    b.setInt(R.id.w_b_text, "setBackgroundColor", 0);
                    b.setTextColor(R.id.w_b_text, 0x99FFFFFF);
                }
                b.setOnClickFillInIntent(R.id.w_b_root, new Intent());
                return b;
            }
            RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_item);
            v.setTextViewText(R.id.w_i_mark, r.mark);
            v.setTextViewText(R.id.w_i_title, r.title);
            v.setTextViewText(R.id.w_i_sub, r.sub);
            v.setTextViewText(R.id.w_i_right, r.right);
            int main = 0xFFFFFFFF;
            int soft = 0xCCFFFFFF;
            if (r.state == 0) {
                main = 0x80FFFFFF;
                soft = 0x66FFFFFF;
            }
            int markColor = r.state == 1 ? 0xFF7CFFB2 : main;
            v.setTextColor(R.id.w_i_mark, markColor);
            v.setTextColor(R.id.w_i_title, main);
            v.setTextColor(R.id.w_i_sub, soft);
            v.setTextColor(R.id.w_i_right, r.state == 1 ? 0xFF7CFFB2 : soft);
            if (r.state == 1) {
                v.setInt(R.id.w_i_root, "setBackgroundResource", R.drawable.widget_chip);
            } else {
                v.setInt(R.id.w_i_root, "setBackgroundColor", 0);
            }
            Intent fill = new Intent();
            fill.putExtra("cid", r.id);
            fill.putExtra("cdate", r.date);
            v.setOnClickFillInIntent(R.id.w_i_root, fill);
            return v;
        }

        @Override
        public RemoteViews getLoadingView() {
            return null;
        }

        @Override
        public int getViewTypeCount() {
            return 2;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public boolean hasStableIds() {
            return false;
        }
    }
}
