package com.subol.classflow;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;
import java.util.TimeZone;

public class ClassWidget extends AppWidgetProvider {
    static final String REFRESH = "com.subol.classflow.REFRESH";

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        updateAll(c);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        if (i != null && REFRESH.equals(i.getAction())) {
            updateAll(c);
        }
    }

    public static void refresh(Context c) {
        updateAll(c);
    }

    static void updateAll(Context c) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            int[] ids = m.getAppWidgetIds(new ComponentName(c, ClassWidget.class));
            if (ids == null || ids.length == 0) {
                return;
            }
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_classflow);
            long wait = fill(c, v);
            Intent open = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
            if (open != null) {
                PendingIntent pi = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                v.setOnClickPendingIntent(R.id.w_root, pi);
            }
            m.updateAppWidget(ids, v);
            schedule(c, wait);
        } catch (Exception e) {
            // ignore
        }
    }

    static void schedule(Context c, long seconds) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            Intent i = new Intent(c, ClassWidget.class);
            i.setAction(REFRESH);
            PendingIntent p = PendingIntent.getBroadcast(c, 1, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + seconds * 1000L, p);
        } catch (Exception e) {
            // ignore
        }
    }

    static void put(RemoteViews v, String tag, String left, String title, String time, String sub, String foot) {
        v.setTextViewText(R.id.w_tag, tag);
        v.setTextViewText(R.id.w_left, left);
        v.setViewVisibility(R.id.w_left, left.length() > 0 ? android.view.View.VISIBLE : android.view.View.GONE);
        v.setTextViewText(R.id.w_title, title);
        v.setTextViewText(R.id.w_time, time);
        v.setTextViewText(R.id.w_sub, sub);
        v.setTextViewText(R.id.w_foot, foot);
    }

    static long fill(Context c, RemoteViews v) {
        String raw = c.getSharedPreferences("classflow", 0).getString("data", null);
        if (raw == null) {
            put(v, "CLASSFLOW", "", "Open the app once", "", "Your classes will appear here", "");
            return 1800;
        }
        try {
            JSONObject d = new JSONObject(raw);
            String tzs = d.optString("tz", "Europe/Moscow");
            TimeZone tz = "device".equals(tzs) ? TimeZone.getDefault() : TimeZone.getTimeZone(tzs);
            boolean h12 = !"24".equals(d.optString("tf", "12"));
            Calendar now = Calendar.getInstance(tz);
            int m = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);
            String today = iso(now);
            int dow = now.get(Calendar.DAY_OF_WEEK) - 1;
            JSONArray cs = d.optJSONArray("c");
            JSONArray xs = d.optJSONArray("x");
            ArrayList<JSONObject> list = new ArrayList<JSONObject>();
            if (cs != null) {
                for (int k = 0; k < cs.length(); k++) {
                    JSONObject o = cs.getJSONObject(k);
                    if (!occurs(o, today, dow)) {
                        continue;
                    }
                    if (cancelled(xs, o.optString("id") + "|" + today)) {
                        continue;
                    }
                    list.add(o);
                }
            }
            Collections.sort(list, new Comparator<JSONObject>() {
                @Override
                public int compare(JSONObject a, JSONObject b) {
                    return mins(a.optString("start")) - mins(b.optString("start"));
                }
            });
            JSONObject live = null;
            JSONObject nxt = null;
            for (JSONObject o : list) {
                int s = mins(o.optString("start"));
                int e = endOf(o);
                if (m >= s && m < e) {
                    if (live == null) {
                        live = o;
                    }
                } else if (s > m && nxt == null) {
                    nxt = o;
                }
            }
            JSONObject cur = live != null ? live : nxt;
            String tag;
            String title;
            String time = "";
            String sub = "";
            String leftTxt = "";
            long wait = 600;
            if (cur == null) {
                tag = list.isEmpty() ? "NO CLASS TODAY" : "ALL CLASSES DONE";
                title = list.isEmpty() ? "Enjoy your free day" : "See you tomorrow";
                wait = 1800;
            } else {
                int s = mins(cur.optString("start"));
                int e = endOf(cur);
                tag = live != null ? "LIVE NOW" : "NEXT CLASS";
                title = cur.optString("subject");
                time = fmt(s, h12) + " to " + fmt(e, h12);
                leftTxt = live != null ? dur(e - m) + " left" : "in " + dur(s - m);
                String mode = "online".equals(cur.optString("mode")) ? "Online" : "Offline";
                sub = cur.optString("teacher") + " , " + mode;
                int gap = live != null ? (e - m) : (s - m);
                wait = Math.max(30, Math.min(600, gap * 60L));
            }
            StringBuilder foot = new StringBuilder();
            int shown = 0;
            for (JSONObject o : list) {
                if (o == cur) {
                    continue;
                }
                if (mins(o.optString("start")) > m && shown < 2) {
                    if (shown == 0) {
                        foot.append("Later: ");
                    } else {
                        foot.append(", ");
                    }
                    foot.append(o.optString("subject")).append(" ").append(fmt(mins(o.optString("start")), h12));
                    shown++;
                }
            }
            JSONArray ts = d.optJSONArray("t");
            long best = Long.MAX_VALUE;
            String taskLine = "";
            if (ts != null) {
                for (int k = 0; k < ts.length(); k++) {
                    try {
                        JSONObject t = ts.getJSONObject(k);
                        long mm = dueMins(t, tz, now);
                        if (mm < best) {
                            best = mm;
                            taskLine = t.optString("type") + ": " + t.optString("title") + " " + (mm < 0 ? "overdue" : "in " + dur(mm));
                        }
                    } catch (Exception ex) {
                        // skip bad task
                    }
                }
            }
            if (taskLine.length() > 0) {
                if (foot.length() > 0) {
                    foot.append("\n");
                }
                foot.append(taskLine);
            }
            put(v, tag, leftTxt, title, time, sub, foot.toString());
            return wait;
        } catch (Exception e) {
            put(v, "CLASSFLOW", "", "Open the app once", "", "Could not read your schedule", "");
            return 1800;
        }
    }

    static boolean occurs(JSONObject o, String today, int dow) {
        String r = o.optString("repeat", "weekly");
        if ("once".equals(r)) {
            return today.equals(o.optString("date"));
        }
        if ("daily".equals(r)) {
            return true;
        }
        JSONArray ds = o.optJSONArray("days");
        if (ds == null) {
            return false;
        }
        for (int k = 0; k < ds.length(); k++) {
            if (ds.optInt(k, -1) == dow) {
                return true;
            }
        }
        return false;
    }

    static boolean cancelled(JSONArray xs, String key) {
        if (xs == null) {
            return false;
        }
        for (int k = 0; k < xs.length(); k++) {
            if (key.equals(xs.optString(k))) {
                return true;
            }
        }
        return false;
    }

    static int mins(String s) {
        try {
            String[] p = s.split(":");
            return Integer.parseInt(p[0]) * 60 + Integer.parseInt(p[1]);
        } catch (Exception e) {
            return 0;
        }
    }

    static int endOf(JSONObject o) {
        int s = mins(o.optString("start"));
        int e = mins(o.optString("end"));
        return e > s ? e : e + 1440;
    }

    static String iso(Calendar c) {
        return String.format(Locale.US, "%04d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    static String fmt(int minutes, boolean h12) {
        int x = minutes % 1440;
        int h = x / 60;
        int mi = x % 60;
        if (!h12) {
            return String.format(Locale.US, "%02d:%02d", h, mi);
        }
        String p = h >= 12 ? "PM" : "AM";
        int hh = h % 12 == 0 ? 12 : h % 12;
        return hh + ":" + String.format(Locale.US, "%02d", mi) + " " + p;
    }

    static String dur(long mm) {
        long a = Math.abs(mm);
        if (a < 60) {
            return a + "m";
        }
        if (a < 1440) {
            return (a / 60) + "h " + (a % 60) + "m";
        }
        return (a / 1440) + "d";
    }

    static long dueMins(JSONObject t, TimeZone tz, Calendar now) {
        String[] dd = t.optString("date").split("-");
        String[] tt = t.optString("time", "23:59").split(":");
        Calendar due = Calendar.getInstance(tz);
        due.clear();
        due.set(Integer.parseInt(dd[0]), Integer.parseInt(dd[1]) - 1, Integer.parseInt(dd[2]), Integer.parseInt(tt[0]), Integer.parseInt(tt[1]), 0);
        return (due.getTimeInMillis() - now.getTimeInMillis()) / 60000L;
    }
}
