package com.subol.classflow;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "ClassFlowWidget")
public class WidgetPlugin extends Plugin {
    @PluginMethod
    public void save(PluginCall call) {
        String d = call.getString("data");
        if (d != null) {
            getContext().getSharedPreferences("classflow", 0).edit().putString("data", d).apply();
            ClassWidget.refresh(getContext());
        }
        call.resolve();
    }
}
