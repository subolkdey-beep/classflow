const fs = require('fs');
const path = require('path');
const main = path.join('android', 'app', 'src', 'main');
if (!fs.existsSync(main)) { console.log('widget setup: android folder not found yet'); process.exit(0); }
const put = (from, to) => { fs.mkdirSync(path.dirname(to), { recursive: true }); fs.copyFileSync(path.join('widget', from), to); };
const jdir = path.join(main, 'java', 'com', 'subol', 'classflow');
['ClassWidget.java', 'WidgetPlugin.java', 'MainActivity.java', 'WidgetService.java'].forEach(f => put(f, path.join(jdir, f)));
put('widget_classflow.xml', path.join(main, 'res', 'layout', 'widget_classflow.xml'));
put('widget_bg.xml', path.join(main, 'res', 'drawable', 'widget_bg.xml'));
put('widget_item.xml', path.join(main, 'res', 'layout', 'widget_item.xml'));
put('widget_break.xml', path.join(main, 'res', 'layout', 'widget_break.xml'));
put('widget_break_bg.xml', path.join(main, 'res', 'drawable', 'widget_break_bg.xml'));
put('widget_free_bg.xml', path.join(main, 'res', 'drawable', 'widget_free_bg.xml'));
put('widget_chip.xml', path.join(main, 'res', 'drawable', 'widget_chip.xml'));
put('widget_info.xml', path.join(main, 'res', 'xml', 'widget_info.xml'));
const mf = path.join(main, 'AndroidManifest.xml');
let x = fs.readFileSync(mf, 'utf8');
if (!x.includes('ClassWidget')) {
  const r = '<receiver android:name="com.subol.classflow.ClassWidget" android:exported="true" android:label="ClassFlow"><intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE" /><action android:name="com.subol.classflow.REFRESH" /></intent-filter><meta-data android:name="android.appwidget.provider" android:resource="@xml/widget_info" /></receiver>\n    </application>';
  x = x.replace('</application>', r);
  fs.writeFileSync(mf, x);
}
x = fs.readFileSync(mf, 'utf8');
if (!x.includes('WidgetService')) {
  x = x.replace('</application>', '<service android:name="com.subol.classflow.WidgetService" android:permission="android.permission.BIND_REMOTEVIEWS" android:exported="false" />\n    </application>');
  fs.writeFileSync(mf, x);
}
console.log('widget setup: done');
