const fs = require('fs');
const path = require('path');
const main = path.join('android', 'app', 'src', 'main');
if (!fs.existsSync(main)) { console.log('widget setup: android folder not found yet'); process.exit(0); }
const put = (from, to) => { fs.mkdirSync(path.dirname(to), { recursive: true }); fs.copyFileSync(path.join('widget', from), to); };
const jdir = path.join(main, 'java', 'com', 'subol', 'classflow');
['ClassWidget.java', 'WidgetPlugin.java', 'MainActivity.java', 'WidgetService.java'].forEach(f => put(f, path.join(jdir, f)));
put('widget_classflow.xml', path.join(main, 'res', 'layout', 'widget_classflow.xml'));
put('widget_item.xml', path.join(main, 'res', 'layout', 'widget_item.xml'));
put('widget_break.xml', path.join(main, 'res', 'layout', 'widget_break.xml'));
put('widget_bg.xml', path.join(main, 'res', 'drawable', 'widget_bg.xml'));
put('widget_break_bg.xml', path.join(main, 'res', 'drawable', 'widget_break_bg.xml'));
put('widget_free_bg.xml', path.join(main, 'res', 'drawable', 'widget_free_bg.xml'));
put('widget_progress.xml', path.join(main, 'res', 'drawable', 'widget_progress.xml'));
put('widget_live_pill.xml', path.join(main, 'res', 'drawable', 'widget_live_pill.xml'));
put('widget_chip.xml', path.join(main, 'res', 'drawable', 'widget_chip.xml'));
put('widget_info.xml', path.join(main, 'res', 'xml', 'widget_info.xml'));
const mf = path.join(main, 'AndroidManifest.xml');
let x = fs.readFileSync(mf, 'utf8');
if (!x.includes('ClassWidget')) {
  const r = '<receiver android:name="com.subol.classflow.ClassWidget" android:exported="true" android:label="ClassFlow"><intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE" /><action android:name="com.subol.classflow.REFRESH" /></intent-filter><meta-data android:name="android.appwidget.provider" android:resource="@xml/widget_info" /></receiver>\n    </application>';
  x = x.replace('</application>', r);
  fs.writeFileSync(mf, x);
}
x = fs.readFileSync(mf, 'utf8');
if (!x.includes('WidgetService')) {
  x = x.replace('</application>', '<service android:name="com.subol.classflow.WidgetService" android:permission="android.permission.BIND_REMOTEVIEWS" android:exported="false" />\n    </application>');
  fs.writeFileSync(mf, x);
}

// Branding: splash screen and app icon
const res = path.join(main, 'res');
const removeSplashPngs = (dir) => {
  fs.readdirSync(dir, { withFileTypes: true }).forEach(e => {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) removeSplashPngs(p);
    else if (e.name === 'splash.png' && path.basename(dir).startsWith('drawable')) fs.unlinkSync(p);
  });
};
removeSplashPngs(res);
const copyTree = (from, to) => {
  fs.mkdirSync(to, { recursive: true });
  fs.readdirSync(from, { withFileTypes: true }).forEach(e => {
    const a = path.join(from, e.name), b = path.join(to, e.name);
    if (e.isDirectory()) copyTree(a, b); else fs.copyFileSync(a, b);
  });
};
if (fs.existsSync('brand')) copyTree('brand', res);
const sf = path.join(res, 'values', 'styles.xml');
if (fs.existsSync(sf)) {
  let st = fs.readFileSync(sf, 'utf8');
  if (!st.includes('windowSplashScreenAnimatedIcon')) {
    st = st.replace(/<style name="AppTheme.NoActionBarLaunch"[\s\S]*?<\/style>/, '<style name="AppTheme.NoActionBarLaunch" parent="Theme.SplashScreen">\n        <item name="android:background">@drawable/splash</item>\n        <item name="windowSplashScreenBackground">#7C3AED</item>\n        <item name="windowSplashScreenAnimatedIcon">@drawable/ic_splash_logo</item>\n    </style>');
    fs.writeFileSync(sf, st);
  }
}
console.log('widget setup: done');
