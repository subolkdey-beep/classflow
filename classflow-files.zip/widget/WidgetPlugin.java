package com.subol.classflow;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "ClassFlowWidget")
public class WidgetPlugin extends Plugin {
    static String pendingId = null;
    static String pendingDate = null;

    @PluginMethod
    public void save(PluginCall call) {
        String d = call.getString("data");
        if (d != null) {
            getContext().getSharedPreferences("classflow", 0).edit().putString("data", d).apply();
            ClassWidget.refresh(getContext());
        }
        call.resolve();
    }

    @PluginMethod
    public void getPending(PluginCall call) {
        JSObject o = new JSObject();
        if (pendingId != null) {
            o.put("id", pendingId);
            o.put("date", pendingDate == null ? "" : pendingDate);
        }
        pendingId = null;
        pendingDate = null;
        call.resolve(o);
    }
}
