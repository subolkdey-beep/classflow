package com.subol.classflow;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;
import java.util.TimeZone;

public class ClassWidget extends AppWidgetProvider {
    static final String REFRESH = "com.subol.classflow.REFRESH";

    static class Row {
        int type = 0;
        int state = 2;
        String mark = "";
        String title = "";
        String sub = "";
        String right = "";
    }

    static class Model {
        String day = "";
        String count = "";
        ArrayList<Row> rows = new ArrayList<Row>();
        long wait = 600;
    }

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        updateAll(c);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        if (i != null && REFRESH.equals(i.getAction())) {
            updateAll(c);
        }
    }

    public static void refresh(Context c) {
        updateAll(c);
    }

    static void updateAll(Context c) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            int[] ids = m.getAppWidgetIds(new ComponentName(c, ClassWidget.class));
            if (ids == null || ids.length == 0) {
                return;
            }
            Model md = compute(c);
            Intent open = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
            for (int k = 0; k < ids.length; k++) {
                int id = ids[k];
                RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_classflow);
                Intent svc = new Intent(c, WidgetService.class);
                svc.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
                svc.setData(Uri.parse(svc.toUri(Intent.URI_INTENT_SCHEME)));
                v.setRemoteAdapter(R.id.w_list, svc);
                v.setEmptyView(R.id.w_list, R.id.w_empty);
                v.setTextViewText(R.id.w_day, md.day);
                v.setTextViewText(R.id.w_count, md.count);
                if (open != null) {
                    PendingIntent head = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                    v.setOnClickPendingIntent(R.id.w_head, head);
                    v.setOnClickPendingIntent(R.id.w_empty, head);
                    PendingIntent tpl = PendingIntent.getActivity(c, 2, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
                    v.setPendingIntentTemplate(R.id.w_list, tpl);
                }
                m.updateAppWidget(id, v);
            }
            m.notifyAppWidgetViewDataChanged(ids, R.id.w_list);
            schedule(c, md.wait);
        } catch (Exception e) {
            // ignore
        }
    }

    static void schedule(Context c, long seconds) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            Intent i = new Intent(c, ClassWidget.class);
            i.setAction(REFRESH);
            PendingIntent p = PendingIntent.getBroadcast(c, 1, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + seconds * 1000L, p);
        } catch (Exception e) {
            // ignore
        }
    }

    static Row info(String t) {
        Row r = new Row();
        r.type = 1;
        r.title = t;
        return r;
    }

    static Model compute(Context c) {
        Model md = new Model();
        String raw = c.getSharedPreferences("classflow", 0).getString("data", null);
        if (raw == null) {
            md.day = "ClassFlow";
            md.rows.add(info("Open the app once to load your classes"));
            md.wait = 1800;
            return md;
        }
        try {
            JSONObject d = new JSONObject(raw);
            String tzs = d.optString("tz", "Europe/Moscow");
            TimeZone tz = "device".equals(tzs) ? TimeZone.getDefault() : TimeZone.getTimeZone(tzs);
            boolean h12 = !"24".equals(d.optString("tf", "12"));
            Calendar now = Calendar.getInstance(tz);
            int m = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);
            String today = iso(now);
            int dow = now.get(Calendar.DAY_OF_WEEK) - 1;
            String[] days = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
            String[] mons = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
            md.day = days[dow] + ", " + now.get(Calendar.DAY_OF_MONTH) + " " + mons[now.get(Calendar.MONTH)];
            JSONArray cs = d.optJSONArray("c");
            JSONArray xs = d.optJSONArray("x");
            ArrayList<JSONObject> list = new ArrayList<JSONObject>();
            if (cs != null) {
                for (int k = 0; k < cs.length(); k++) {
                    JSONObject o = cs.getJSONObject(k);
                    if (!occurs(o, today, dow)) {
                        continue;
                    }
                    if (cancelled(xs, o.optString("id") + "|" + today)) {
                        continue;
                    }
                    list.add(o);
                }
            }
            Collections.sort(list, new Comparator<JSONObject>() {
                @Override
                public int compare(JSONObject a, JSONObject b) {
                    return mins(a.optString("start")) - mins(b.optString("start"));
                }
            });
            int done = 0;
            long minGap = Long.MAX_VALUE;
            for (int k = 0; k < list.size(); k++) {
                JSONObject o = list.get(k);
                int s = mins(o.optString("start"));
                int e = endOf(o);
                boolean online = "online".equals(o.optString("mode"));
                String teacher = o.optString("teacher");
                Row r = new Row();
                r.type = 0;
                r.title = o.optString("subject");
                r.sub = fmt(s, h12) + " to " + fmt(e, h12) + ", " + (online ? "Online" : "Offline") + (teacher.length() > 0 ? ", " + teacher : "");
                if (m >= e) {
                    r.state = 0;
                    r.mark = "\u2713";
                    r.right = "Done";
                    done++;
                } else if (m >= s) {
                    r.state = 1;
                    r.mark = "\u25CF";
                    r.right = dur(e - m) + " left";
                    minGap = Math.min(minGap, e - m);
                } else {
                    r.state = 2;
                    r.mark = "\u25CB";
                    r.right = "in " + dur(s - m);
                    minGap = Math.min(minGap, s - m);
                }
                md.rows.add(r);
                if (k + 1 < list.size()) {
                    int gap = mins(list.get(k + 1).optString("start")) - e;
                    if (gap > 0) {
                        md.rows.add(info((gap > 60 ? "Free time " : "Break ") + dur(gap)));
                    }
                }
            }
            if (list.isEmpty()) {
                md.count = "Free day";
            } else if (done == list.size()) {
                md.count = "All done";
            } else {
                md.count = (list.size() - done) + " left";
            }
            JSONArray ts = d.optJSONArray("t");
            long best = Long.MAX_VALUE;
            String taskLine = "";
            if (ts != null) {
                for (int k = 0; k < ts.length(); k++) {
                    try {
                        JSONObject t = ts.getJSONObject(k);
                        long mm = dueMins(t, tz, now);
                        if (mm < best) {
                            best = mm;
                            taskLine = t.optString("type") + ": " + t.optString("title") + " " + (mm < 0 ? "overdue" : "in " + dur(mm));
                        }
                    } catch (Exception ex) {
                        // skip bad task
                    }
                }
            }
            if (taskLine.length() > 0) {
                md.rows.add(info(taskLine));
            }
            long w = 600;
            if (minGap != Long.MAX_VALUE) {
                w = Math.min(w, minGap * 60L);
            }
            w = Math.min(w, (1440 - m) * 60L + 10L);
            md.wait = Math.max(30L, w);
        } catch (Exception e) {
            md.rows.clear();
            md.day = "ClassFlow";
            md.rows.add(info("Could not read your schedule"));
            md.wait = 1800;
        }
        return md;
    }

    static boolean occurs(JSONObject o, String today, int dow) {
        String r = o.optString("repeat", "weekly");
        if ("once".equals(r)) {
            return today.equals(o.optString("date"));
        }
        if ("daily".equals(r)) {
            return true;
        }
        JSONArray ds = o.optJSONArray("days");
        if (ds == null) {
            return false;
        }
        for (int k = 0; k < ds.length(); k++) {
            if (ds.optInt(k, -1) == dow) {
                return true;
            }
        }
        return false;
    }

    static boolean cancelled(JSONArray xs, String key) {
        if (xs == null) {
            return false;
        }
        for (int k = 0; k < xs.length(); k++) {
            if (key.equals(xs.optString(k))) {
                return true;
            }
        }
        return false;
    }

    static int mins(String s) {
        try {
            String[] p = s.split(":");
            return Integer.parseInt(p[0]) * 60 + Integer.parseInt(p[1]);
        } catch (Exception e) {
            return 0;
        }
    }

    static int endOf(JSONObject o) {
        int s = mins(o.optString("start"));
        int e = mins(o.optString("end"));
        return e > s ? e : e + 1440;
    }

    static String iso(Calendar c) {
        return String.format(Locale.US, "%04d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    static String fmt(int minutes, boolean h12) {
        int x = minutes % 1440;
        int h = x / 60;
        int mi = x % 60;
        if (!h12) {
            return String.format(Locale.US, "%02d:%02d", h, mi);
        }
        String p = h >= 12 ? "PM" : "AM";
        int hh = h % 12 == 0 ? 12 : h % 12;
        return hh + ":" + String.format(Locale.US, "%02d", mi) + " " + p;
    }

    static String dur(long mm) {
        long a = Math.abs(mm);
        if (a < 60) {
            return a + "m";
        }
        if (a < 1440) {
            return (a / 60) + "h " + (a % 60) + "m";
        }
        return (a / 1440) + "d";
    }

    static long dueMins(JSONObject t, TimeZone tz, Calendar now) {
        String[] dd = t.optString("date").split("-");
        String[] tt = t.optString("time", "23:59").split(":");
        Calendar due = Calendar.getInstance(tz);
        due.clear();
        due.set(Integer.parseInt(dd[0]), Integer.parseInt(dd[1]) - 1, Integer.parseInt(dd[2]), Integer.parseInt(tt[0]), Integer.parseInt(tt[1]), 0);
        return (due.getTimeInMillis() - now.getTimeInMillis()) / 60000L;
    }
}
