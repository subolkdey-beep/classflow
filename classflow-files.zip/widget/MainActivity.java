package com.subol.classflow;

import android.content.Intent;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(WidgetPlugin.class);
        super.onCreate(savedInstanceState);
        grab(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (grab(intent)) {
            try {
                getBridge().getWebView().evaluateJavascript("window.cfCheck && window.cfCheck()", null);
            } catch (Exception e) {
                // ignore
            }
        }
    }

    private boolean grab(Intent i) {
        if (i == null) {
            return false;
        }
        String id = i.getStringExtra("cid");
        if (id == null) {
            return false;
        }
        WidgetPlugin.pendingId = id;
        WidgetPlugin.pendingDate = i.getStringExtra("cdate");
        i.removeExtra("cid");
        i.removeExtra("cdate");
        return true;
    }
}
